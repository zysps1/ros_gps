nmea_navsat_driver
===============

增加北斗卫星支持，增加发布 [gps_common/GPSFix](http://docs.ros.org/api/gps_common/html/msg/GPSFix.html) 话题，方便用户了解卫星连接状态

Add support for Beidou, add topic `extend_fix`, make it easier for user to get info about GPS status.

ROS driver to parse NMEA strings and publish standard ROS NavSat message types. Does not require the GPSD daemon to be running.

API
---

This package has no released Code API.

The ROS API documentation and other information can be found at http://ros.org/wiki/nmea_navsat_driver
