^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package map_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.14.1 (2020-11-02)
-------------------

1.14.0 (2020-03-10)
-------------------
* Bump CMake version to avoid CMP0048
  Signed-off-by: Shane Loretz <sloretz@osrfoundation.org>
* Contributors: Shane Loretz

1.13.0 (2015-03-16)
-------------------
* initial release from new repository
* Contributors: Michael Ferguson
