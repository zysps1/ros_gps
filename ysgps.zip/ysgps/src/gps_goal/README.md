# gps_goal [![Build Status](http://build.ros.org/buildStatus/icon?job=Kbin_uX64__gps_goal__ubuntu_xenial_amd64__binary)](http://build.ros.org/job/Kbin_uX64__gps_goal__ubuntu_xenial_amd64__binary)

Set a ROS navigation goal using latitude and longitude.

## Installation

```
$ sudo apt-get install ros-kinetic-gps-goal hugin-tools enblend
```

**Full documentation on wiki: [http://wiki.ros.org/gps_goal](http://wiki.ros.org/gps_goal)**
