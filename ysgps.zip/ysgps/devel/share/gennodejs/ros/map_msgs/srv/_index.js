
"use strict";

let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let GetMapROI = require('./GetMapROI.js')
let GetPointMap = require('./GetPointMap.js')
let SetMapProjections = require('./SetMapProjections.js')
let SaveMap = require('./SaveMap.js')

module.exports = {
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetPointMapROI: GetPointMapROI,
  GetMapROI: GetMapROI,
  GetPointMap: GetPointMap,
  SetMapProjections: SetMapProjections,
  SaveMap: SaveMap,
};
