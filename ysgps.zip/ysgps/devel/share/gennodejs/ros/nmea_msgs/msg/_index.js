
"use strict";

let Gpgsv = require('./Gpgsv.js');
let GpgsvSatellite = require('./GpgsvSatellite.js');
let Gpgga = require('./Gpgga.js');
let Gpgst = require('./Gpgst.js');
let Sentence = require('./Sentence.js');
let Gprmc = require('./Gprmc.js');
let Gpgsa = require('./Gpgsa.js');

module.exports = {
  Gpgsv: Gpgsv,
  GpgsvSatellite: GpgsvSatellite,
  Gpgga: Gpgga,
  Gpgst: Gpgst,
  Sentence: Sentence,
  Gprmc: Gprmc,
  Gpgsa: Gpgsa,
};
